# PRD – Heineken – Modelo de Costos & Retail (ES)
Requerimientos funcionales y no funcionales en español.
