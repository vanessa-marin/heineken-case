# Learnings – Heineken – Modelo de Costos & Retail (EN)
Key learnings from the project in English.
