# Case Summary – Heineken – Modelo de Costos & Retail (ES)
Resumen ejecutivo del caso en español.
