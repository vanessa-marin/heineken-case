# Metrics – Heineken – Modelo de Costos & Retail (ES)
Métricas clave, NSM y KPIs definidos para el producto.
