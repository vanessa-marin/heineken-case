# Metrics – Heineken – Modelo de Costos & Retail (EN)
North Star Metric and key KPIs for the product.
