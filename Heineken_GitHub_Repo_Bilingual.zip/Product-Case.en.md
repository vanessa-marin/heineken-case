# Product Case – Heineken – Modelo de Costos & Retail (EN)
Full case description in English. Modelo de costos y vista de catálogo/retail para la toma de decisiones comerciales.
