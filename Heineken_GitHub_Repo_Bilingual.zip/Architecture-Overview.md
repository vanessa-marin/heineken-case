# Architecture Overview – Heineken – Modelo de Costos & Retail (ES)
Descripción funcional y de arquitectura (ES).
