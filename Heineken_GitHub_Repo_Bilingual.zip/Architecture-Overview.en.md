# Architecture Overview – Heineken – Modelo de Costos & Retail (EN)
Functional and architecture overview (EN).
