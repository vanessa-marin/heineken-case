# Case Summary – Heineken – Modelo de Costos & Retail (EN)
Executive summary of the case in English.
