# Learnings – Heineken – Modelo de Costos & Retail (ES)
Aprendizajes clave del proyecto en español.
