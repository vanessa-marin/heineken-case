# Pitch – Heineken – Modelo de Costos & Retail (EN)
60–90 seconds pitch in English.
