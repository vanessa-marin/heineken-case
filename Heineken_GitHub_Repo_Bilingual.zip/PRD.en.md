# PRD – Heineken – Modelo de Costos & Retail (EN)
Functional and non-functional requirements in English.
